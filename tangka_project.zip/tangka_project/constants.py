ACTIVITY = "activity"
ACTIVITIES = "activities"
NAME = "name"
INSTRUCTOR = "instructor"
DESCRIPTION = "description"
START = "start"
ROOM = "room"
END = "end"
EMAIL = "email"
ATTENDEE = "attendee"
ATTENDEES = "attendees"
FIRST_NAME = "first_name"
LAST_NAME = "last_name"
PHONE = "phone"
NUM_ATTENDEES = "num_attendees"
ALL_ATTENDEES = "all_attendees"
ACTIVITY_LIST = "activity_list"
CLIENT_ID = 'lBoA5gIbcus7vZYnYLKKhmrAbxd3Qb9t'
CLIENT_SECRET = 'OY2q4WlsbHe-nXERy5NCUMNU6L-E678dAfI4jVrljYW6lfn8u-9gqUhCXfWdhoL-'
DOMAIN = 'recreational-activities-api.us.auth0.com'
ALGORITHMS = ["RS256"]
ACTIVITY_ID = "activity_id"
ATTENDEE_LIST = "attendee_list"
ATTENDEE_ID = "attendee_id"
NUM_ACTIVITIES = "num_activities"
ACTIVITY_EXTRA_ATTR_MSG = {"Error": "The request object has at least one attribute that is not allowed"}
INVALID_TYPE = {"Error": "The request object has at least one attribute that is of an invalid type."}
MISSING_ATTR = {"Error": "The request object is missing at least one of the required attributes."}
NOT_SUPPORTED = {'Error': 'Content type requested is not supported by API.'}
APPLICATION_JSON = 'application/json'
UNSUPPORTED_MEDIA = {"Error": "Unsupported Media Type"}
ATTENDEE_ALREADY_EXISTS = {"Error": "The attendee is already registered for this activity."}
ATTENDEE_NOT_IN_ACTIVITY = {"Error": "The attendee is not registered for this activity"}
ATTENDEE_EXTRA_ATTR = 'The request object has at least one attribute that is not allowed.'

MISSING_TOKEN = {"Error": "Missing Authorization token."}

INVALID_DESC_LENGTH = {"Error": "The description field length an invalid length, description length must "
                                "be at least 5 characters and at most 50 characters."}
INVALID_NAME_LENGTH = {"Error": "The name field length is an invalid length, name length must be at least 5 "
                                "characters and at most 30 characters."}
INVALID_START_TIME = {"Error": "The start time is larger than the end time."}
INVALID_TIME_CHOICES = {"Error": "The start and end field must after the date Jan 01 2019 08:00:00 GMT+0000, "
                                 "start time must be earlier than end time."}
INVALID_ROOM_NUMBER = {"Error": "The room number is invalid, must range between 1-300 inclusively."}
ROOM_OVERLAP = {"Error": "The time overlaps with another activity. Please choose a different time."}
PUBLIC = "public"
SUB = "sub"

INVALID_TYPE_LIMIT_OFFSET = {"Error": "The offset field and or limit field is not an integer."}
INVALID_ACTIVITY_ID = {"Error": "No activity with this id exists."}
INVALID_ATTENDEE_ID = {"Error": "No attendee with this id exists."}
INVALID_ATTENDEE_ACTIVITY_ID = {"Error": "No activity with this activity_id exists and/or attendee with this "
                                         "attendee_id."}
UNAUTH_TO_ADD = {"Error": "You are not authorized to add attendees to this activity."}
CONST_START_DATE_CUTOFF = 1546329600

ERR_PRIVATE_ACTIVITY = {"Error": "The activity requested is private and you are unauthorized to view activity."}
ERR_PRIVATE_ACTIVITY_NO_AUTH = {"Error": "Unauthorized to view activity requested, missing token or token is invalid "
                                         "or expired"}
ERR_PHONE_LEN = {
    "Error": "The phone number is of an invalid length, phone numbers accepted must be 10 digits in length"}
ATTENDEE_NOT_UNIQUE = {"Error": "The attendee provided already exists."}

MULTIPLE_ACTIVITIES = {"Error": "The attendee has activities in activity_list that must be removed before being "
                                "deleted."}
MULTIPLE_ATTENDEES = {"Error": "The activity has attendees that are still registered, attendees must be removed "
                               "before deleting."}

ACTIVITY_WRONG_USER = {"Error": "You are not authorized to delete requested activity"}

OFFSET_LIMIT_INVALID = {"Error": "The offset and/or  limit are not integers "}

USERNAME = "k.tang.1993@gmail.com"
PASSWORD = "Food123@@"

AUTH_MANAGERMENT_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjQzRnYyekxYMkxDbkdJdkVoY01vaiJ9.eyJpc3MiOiJodHRwczovL3JlY3JlYXRpb25hbC1hY3Rpdml0aWVzLWFwaS51cy5hdXRoMC5jb20vIiwic3ViIjoiUE5pNTF2cjJ6VFhsUm41azBGR3REd2xSemxscVVpdjNAY2xpZW50cyIsImF1ZCI6Imh0dHBzOi8vcmVjcmVhdGlvbmFsLWFjdGl2aXRpZXMtYXBpLnVzLmF1dGgwLmNvbS9hcGkvdjIvIiwiaWF0IjoxNjIzMDQxMzM4LCJleHAiOjE2MjMxMjc3MzgsImF6cCI6IlBOaTUxdnIyelRYbFJuNWswRkd0RHdsUnpsbHFVaXYzIiwic2NvcGUiOiJyZWFkOmNsaWVudF9ncmFudHMgY3JlYXRlOmNsaWVudF9ncmFudHMgZGVsZXRlOmNsaWVudF9ncmFudHMgdXBkYXRlOmNsaWVudF9ncmFudHMgcmVhZDp1c2VycyB1cGRhdGU6dXNlcnMgZGVsZXRlOnVzZXJzIGNyZWF0ZTp1c2VycyByZWFkOnVzZXJzX2FwcF9tZXRhZGF0YSB1cGRhdGU6dXNlcnNfYXBwX21ldGFkYXRhIGRlbGV0ZTp1c2Vyc19hcHBfbWV0YWRhdGEgY3JlYXRlOnVzZXJzX2FwcF9tZXRhZGF0YSByZWFkOnVzZXJfY3VzdG9tX2Jsb2NrcyBjcmVhdGU6dXNlcl9jdXN0b21fYmxvY2tzIGRlbGV0ZTp1c2VyX2N1c3RvbV9ibG9ja3MgY3JlYXRlOnVzZXJfdGlja2V0cyByZWFkOmNsaWVudHMgdXBkYXRlOmNsaWVudHMgZGVsZXRlOmNsaWVudHMgY3JlYXRlOmNsaWVudHMgcmVhZDpjbGllbnRfa2V5cyB1cGRhdGU6Y2xpZW50X2tleXMgZGVsZXRlOmNsaWVudF9rZXlzIGNyZWF0ZTpjbGllbnRfa2V5cyByZWFkOmNvbm5lY3Rpb25zIHVwZGF0ZTpjb25uZWN0aW9ucyBkZWxldGU6Y29ubmVjdGlvbnMgY3JlYXRlOmNvbm5lY3Rpb25zIHJlYWQ6cmVzb3VyY2Vfc2VydmVycyB1cGRhdGU6cmVzb3VyY2Vfc2VydmVycyBkZWxldGU6cmVzb3VyY2Vfc2VydmVycyBjcmVhdGU6cmVzb3VyY2Vfc2VydmVycyByZWFkOmRldmljZV9jcmVkZW50aWFscyB1cGRhdGU6ZGV2aWNlX2NyZWRlbnRpYWxzIGRlbGV0ZTpkZXZpY2VfY3JlZGVudGlhbHMgY3JlYXRlOmRldmljZV9jcmVkZW50aWFscyByZWFkOnJ1bGVzIHVwZGF0ZTpydWxlcyBkZWxldGU6cnVsZXMgY3JlYXRlOnJ1bGVzIHJlYWQ6cnVsZXNfY29uZmlncyB1cGRhdGU6cnVsZXNfY29uZmlncyBkZWxldGU6cnVsZXNfY29uZmlncyByZWFkOmhvb2tzIHVwZGF0ZTpob29rcyBkZWxldGU6aG9va3MgY3JlYXRlOmhvb2tzIHJlYWQ6YWN0aW9ucyB1cGRhdGU6YWN0aW9ucyBkZWxldGU6YWN0aW9ucyBjcmVhdGU6YWN0aW9ucyByZWFkOmVtYWlsX3Byb3ZpZGVyIHVwZGF0ZTplbWFpbF9wcm92aWRlciBkZWxldGU6ZW1haWxfcHJvdmlkZXIgY3JlYXRlOmVtYWlsX3Byb3ZpZGVyIGJsYWNrbGlzdDp0b2tlbnMgcmVhZDpzdGF0cyByZWFkOmluc2lnaHRzIHJlYWQ6dGVuYW50X3NldHRpbmdzIHVwZGF0ZTp0ZW5hbnRfc2V0dGluZ3MgcmVhZDpsb2dzIHJlYWQ6bG9nc191c2VycyByZWFkOnNoaWVsZHMgY3JlYXRlOnNoaWVsZHMgdXBkYXRlOnNoaWVsZHMgZGVsZXRlOnNoaWVsZHMgcmVhZDphbm9tYWx5X2Jsb2NrcyBkZWxldGU6YW5vbWFseV9ibG9ja3MgdXBkYXRlOnRyaWdnZXJzIHJlYWQ6dHJpZ2dlcnMgcmVhZDpncmFudHMgZGVsZXRlOmdyYW50cyByZWFkOmd1YXJkaWFuX2ZhY3RvcnMgdXBkYXRlOmd1YXJkaWFuX2ZhY3RvcnMgcmVhZDpndWFyZGlhbl9lbnJvbGxtZW50cyBkZWxldGU6Z3VhcmRpYW5fZW5yb2xsbWVudHMgY3JlYXRlOmd1YXJkaWFuX2Vucm9sbG1lbnRfdGlja2V0cyByZWFkOnVzZXJfaWRwX3Rva2VucyBjcmVhdGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiBkZWxldGU6cGFzc3dvcmRzX2NoZWNraW5nX2pvYiByZWFkOmN1c3RvbV9kb21haW5zIGRlbGV0ZTpjdXN0b21fZG9tYWlucyBjcmVhdGU6Y3VzdG9tX2RvbWFpbnMgdXBkYXRlOmN1c3RvbV9kb21haW5zIHJlYWQ6ZW1haWxfdGVtcGxhdGVzIGNyZWF0ZTplbWFpbF90ZW1wbGF0ZXMgdXBkYXRlOmVtYWlsX3RlbXBsYXRlcyByZWFkOm1mYV9wb2xpY2llcyB1cGRhdGU6bWZhX3BvbGljaWVzIHJlYWQ6cm9sZXMgY3JlYXRlOnJvbGVzIGRlbGV0ZTpyb2xlcyB1cGRhdGU6cm9sZXMgcmVhZDpwcm9tcHRzIHVwZGF0ZTpwcm9tcHRzIHJlYWQ6YnJhbmRpbmcgdXBkYXRlOmJyYW5kaW5nIGRlbGV0ZTpicmFuZGluZyByZWFkOmxvZ19zdHJlYW1zIGNyZWF0ZTpsb2dfc3RyZWFtcyBkZWxldGU6bG9nX3N0cmVhbXMgdXBkYXRlOmxvZ19zdHJlYW1zIGNyZWF0ZTpzaWduaW5nX2tleXMgcmVhZDpzaWduaW5nX2tleXMgdXBkYXRlOnNpZ25pbmdfa2V5cyByZWFkOmxpbWl0cyB1cGRhdGU6bGltaXRzIGNyZWF0ZTpyb2xlX21lbWJlcnMgcmVhZDpyb2xlX21lbWJlcnMgZGVsZXRlOnJvbGVfbWVtYmVycyByZWFkOmVudGl0bGVtZW50cyByZWFkOmF0dGFja19wcm90ZWN0aW9uIHVwZGF0ZTphdHRhY2tfcHJvdGVjdGlvbiByZWFkOm9yZ2FuaXphdGlvbnMgdXBkYXRlOm9yZ2FuaXphdGlvbnMgY3JlYXRlOm9yZ2FuaXphdGlvbnMgZGVsZXRlOm9yZ2FuaXphdGlvbnMgY3JlYXRlOm9yZ2FuaXphdGlvbl9tZW1iZXJzIHJlYWQ6b3JnYW5pemF0aW9uX21lbWJlcnMgZGVsZXRlOm9yZ2FuaXphdGlvbl9tZW1iZXJzIGNyZWF0ZTpvcmdhbml6YXRpb25fY29ubmVjdGlvbnMgcmVhZDpvcmdhbml6YXRpb25fY29ubmVjdGlvbnMgdXBkYXRlOm9yZ2FuaXphdGlvbl9jb25uZWN0aW9ucyBkZWxldGU6b3JnYW5pemF0aW9uX2Nvbm5lY3Rpb25zIGNyZWF0ZTpvcmdhbml6YXRpb25fbWVtYmVyX3JvbGVzIHJlYWQ6b3JnYW5pemF0aW9uX21lbWJlcl9yb2xlcyBkZWxldGU6b3JnYW5pemF0aW9uX21lbWJlcl9yb2xlcyBjcmVhdGU6b3JnYW5pemF0aW9uX2ludml0YXRpb25zIHJlYWQ6b3JnYW5pemF0aW9uX2ludml0YXRpb25zIGRlbGV0ZTpvcmdhbml6YXRpb25faW52aXRhdGlvbnMiLCJndHkiOiJjbGllbnQtY3JlZGVudGlhbHMifQ.qbOgMJkQmTbErVDTWyUPUDmY4w2voimj_1j2Au8NXHB2nr-sSC1AvF9hDGuUn_RrWuKtGS-Glk7AhflHmISTMz9vpYInS1pX1tVYzBxdV4OF7GQ4YfyunJuOx7MwA_YYK_1jSDrwY5w4TdzilEEZscMV0_cgfeXI1PGEvlQHSd98wFq-68Vd7aeNU8uz7YePBuA2z_o0kC_M8_JTEUdbIULG-WUjqg88eM9mr7mD9XFR20sqss9Jq-iaLrpa5Wp1qw17R9SLbgkpYZrrwCQVPjjXY7Bz95rVQZ10uVIXVYGOLvJj7zxOvvRK0euBaGPpWItgpX1EoW0OlFSIxwCxAQ"
